<?php
  header("location: ../");
	
?>